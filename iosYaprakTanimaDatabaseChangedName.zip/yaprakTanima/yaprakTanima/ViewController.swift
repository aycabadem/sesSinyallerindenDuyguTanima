//
//  ViewController.swift
//  yaprakTanima
//
//  Created by Cem Ergin on 27.05.2019.
//  Copyright © 2019 Cem Ergin. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseDatabase

class ViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {

    @IBOutlet weak var myImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func fotoGonder(_ sender: Any) {
    }
    
    @IBAction func fotosec(_ sender: Any) {
        print("program basladi, fotograf secilmeye hazir")

        let image = UIImagePickerController()
        image.delegate = self
        
        image.sourceType = UIImagePickerController.SourceType.photoLibrary
        image.allowsEditing = false
        self.present(image, animated:true)
        {
            
        }
        
        
    }
    
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        /*
        if let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        {
            myImageView.image = image
        }
        else
        {
            print("hata var")
        }
         */
        let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        myImageView.image = image
        self.dismiss(animated:true, completion:nil)
        
        let database = Database.database().reference()
        let storage = Storage.storage().reference()
        let tempImageRef = storage.child("tmpDir/iosBizimGonderdigimiz.jpg")
        
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpeg"
        /*
        tempImageRef.putData(UIImage(image).jpegData(compressionQuality:0.8), metadata: metaData){(data,error) in
            if error==nil{
                print("upload basarili")
            }
            else
            {
                print(error?.localizedDescription)
            }
            
        }
         */
        if let imageData = image?.jpegData(compressionQuality: 0.8){
        tempImageRef.putData(imageData, metadata:metaData)
        print("upload islemi tamam")
        }
        let downloadURL = tempImageRef.downloadURL { (url, error) in
            if error==nil{
                print(url)
                var myUrl = url?.absoluteString
                print("string url: ",myUrl)
                database.child("images/url").setValue(myUrl)
            }
            else
            {
                print("url alinamadi")
            }
        }
    }
    
}

